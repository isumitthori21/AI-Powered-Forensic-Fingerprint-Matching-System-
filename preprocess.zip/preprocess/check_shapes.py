# C:/Project/preprocess/check_shapes.py
import numpy as np
import os

p = np.load('C:/Project/Outputs/pairs.npy')
l = np.load('C:/Project/Outputs/labels.npy')
print(f"Pairs: {p.shape}, Labels: {l.shape}")
print(f"Matches: {sum(l)}, No-matches: {len(l)-sum(l)}")