# C:/Project/preprocess/combine_batches.py
import numpy as np
import os

output_dir = 'C:/Project/Outputs'
batches = []
for file in sorted(os.listdir(output_dir)):
    if file.startswith('preprocessed_batch_') and file.endswith('.npy'):
        batch = np.load(os.path.join(output_dir, file))
        batches.append(batch)
        print(f"Loaded {file} → {batch.shape}")

X = np.concatenate(batches, axis=0)
print(f"Combined X.shape: {X.shape}")

# Save
np.save('C:/Project/Outputs/X_preprocessed.npy', X)
print("Saved X_preprocessed.npy")

# Also save paths if available
if os.path.exists('C:/Project/Outputs/all_file_paths.npy'):
    paths = np.load('C:/Project/Outputs/all_file_paths.npy', allow_pickle=True)
    print(f"Loaded {len(paths)} file paths")
else:
    print("all_file_paths.npy not found!")
