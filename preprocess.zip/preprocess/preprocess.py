# C:/Project/preprocess/preprocess.py
import cv2
import os
import numpy as np

def preprocess_image(img_path):
    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        print(f"Failed to load: {img_path}")
        return None
    img = cv2.resize(img, (128, 128))
    img = cv2.equalizeHist(img)  # Better than Otsu for fingerprints
    return img.astype(np.float32) / 255.0

data_dir = 'C:/Project/dataset/SOCOFing'
batch_size = 1000
all_images = []
all_paths = []  # Keep track of file paths

print("Scanning SOCOFing dataset...")

# Only include Real + _CR files
file_paths = []
for root, _, files in os.walk(data_dir):
    for file in files:
        if file.lower().endswith('.bmp'):
            if 'Altered' in root and not file.lower().endswith('_cr.bmp'):
                continue  # Skip non-CR altered
            file_paths.append(os.path.join(root, file))

print(f"Found {len(file_paths)} valid images (Real + _CR)")

os.makedirs('C:/Project/Outputs', exist_ok=True)

for i in range(0, len(file_paths), batch_size):
    batch_paths = file_paths[i:i + batch_size]
    batch_images = []
    for img_path in batch_paths:
        img = preprocess_image(img_path)
        if img is not None:
            batch_images.append(img)
            all_paths.append(img_path)
    
    if batch_images:
        batch_array = np.array(batch_images)[..., np.newaxis]  # (N, 128, 128, 1)
        np.save(f'C:/Project/Outputs/preprocessed_batch_{i//batch_size}.npy', batch_array)
        print(f"Saved batch {i//batch_size}: {len(batch_images)} images")
        all_images.extend(batch_images)

print(f"Total preprocessed: {len(all_images)} images")
np.save('C:/Project/Outputs/all_file_paths.npy', np.array(all_paths, dtype=object))
print("Saved all_file_paths.npy")
    