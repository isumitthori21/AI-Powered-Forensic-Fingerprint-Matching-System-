# C:/Project/preprocess/make_pairs.py
import numpy as np
import random
import os

print("Starting make_pairs.py...")

# Load X
X = np.load('C:/Project/Outputs/X_preprocessed.npy')
print(f"Loaded X: {X.shape}")

# === STEP 1: Re-build file_to_index from ORIGINAL dataset paths ===
print("\nRebuilding file_to_index from original dataset...")

real_dir = 'C:/Project/dataset/SOCOFing/Real'
altered_dirs = [
    'C:/Project/dataset/SOCOFing/Altered/Altered-Easy',
    'C:/Project/dataset/SOCOFing/Altered/Altered-Medium',
    'C:/Project/dataset/SOCOFing/Altered/Altered-Hard'
]

# Collect ALL original file paths (same as in dataset)
all_original_paths = []

# Real
for f in os.listdir(real_dir):
    if f.lower().endswith('.bmp'):
        all_original_paths.append(os.path.join(real_dir, f))

# Altered
for d in altered_dirs:
    if os.path.exists(d):
        for f in os.listdir(d):
            if f.lower().endswith('_cr.bmp'):
                all_original_paths.append(os.path.join(d, f))

print(f"Total original files found: {len(all_original_paths)}")

# === REBUILD file_to_index using ORIGINAL paths ===
file_to_index = {}
for idx, full_path in enumerate(all_original_paths):
    file_to_index[full_path] = idx

print(f"file_to_index built with {len(file_to_index)} entries")

# === Load preprocessed paths (just for verification) ===
try:
    paths = np.load('C:/Project/Outputs/all_file_paths.npy', allow_pickle=True)
    print(f"Preprocessed paths count: {len(paths)}")
except:
    print("all_file_paths.npy not found — using original paths only")
    paths = all_original_paths

# === Collect real and altered files ===
real_files = [f for f in os.listdir(real_dir) if f.lower().endswith('.bmp')]
altered_files = []
for d in altered_dirs:
    if os.path.exists(d):
        files = [f for f in os.listdir(d) if f.lower().endswith('_cr.bmp')]
        altered_files.extend([(d, f) for f in files])

print(f"Real: {len(real_files)}, Altered _CR: {len(altered_files)}")

# === Normalize name ===
def normalize_name(filename):
    name = filename.rsplit('.', 1)[0]
    name = name.rsplit('_CR', 1)[0]
    return name.upper()

# === Build lookup dicts ===
real_dict = {normalize_name(f): f for f in real_files}
altered_dict = {}
for d, f in altered_files:
    key = normalize_name(f)
    if key not in altered_dict:
        altered_dict[key] = []
    altered_dict[key].append((d, f))

print(f"Unique real: {len(real_dict)}, Unique altered: {len(altered_dict)}")

# === MATCHING PAIRS ===
pairs, labels = [], []
match_count = 0
max_pairs = 1000
target = max_pairs // 2

print(f"\nFinding {target} matching pairs...")

used = set()

for real_file in real_files:
    if match_count >= target:
        break
    key = normalize_name(real_file)
    if key in altered_dict and key not in used:
        alt_dir, alt_file = altered_dict[key][0]
        used.add(key)

        real_path = os.path.join(real_dir, real_file)
        alt_path = os.path.join(alt_dir, alt_file)

        i1 = file_to_index.get(real_path)
        i2 = file_to_index.get(alt_path)

        if i1 is not None and i2 is not None and i1 < len(X) and i2 < len(X):
            pairs.append([X[i1], X[i2]])
            labels.append(1)
            match_count += 1
            print(f"MATCH {match_count}: {real_file} ↔ {alt_file}")
        else:
            print(f"INDEX OUT OF RANGE: {real_file}({i1}), {alt_file}({i2}) | X.shape={X.shape}")
    else:
        if match_count < 3:
            print(f"NO MATCH: {real_file}")

print(f"Total MATCHING pairs: {match_count}")

# === NON-MATCHING PAIRS ===
print(f"\nGenerating {match_count} non-matching pairs...")
no_match_count = 0
n = len(X)

while no_match_count < match_count:
    i1, i2 = random.sample(range(n), 2)
    f1 = os.path.basename(all_original_paths[i1])
    f2 = os.path.basename(all_original_paths[i2])
    if normalize_name(f1) != normalize_name(f2):
        pairs.append([X[i1], X[i2]])
        labels.append(0)
        no_match_count += 1
        if no_match_count <= 3:
            print(f"NO-MATCH {no_match_count}: {f1} ≠ {f2}")

# === SAVE ===
pairs = np.array(pairs, dtype=object)
labels = np.array(labels)

os.makedirs('C:/Project/Outputs', exist_ok=True)
np.save('C:/Project/Outputs/pairs.npy', pairs)
np.save('C:/Project/Outputs/labels.npy', labels)

print("\n" + "="*60)
print(f"FINAL: {len(pairs)} pairs → {sum(labels)} match, {len(labels)-sum(labels)} no-match")
print("pairs.npy & labels.npy saved!")
print("="*60)